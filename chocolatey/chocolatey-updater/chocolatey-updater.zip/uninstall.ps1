﻿$PackageName = "choco-upgrade-all-at-startup"

C:\ProgramData\chocolatey\choco.exe uninstall $PackageName -y

$PackageName = "choco-upgrade-all-at"
C:\ProgramData\chocolatey\choco.exe uninstall $PackageName -y
