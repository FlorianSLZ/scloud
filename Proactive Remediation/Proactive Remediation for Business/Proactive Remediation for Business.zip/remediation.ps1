Remove-Item "C:\Users\*\Desktop\*- Copy*.lnk" -Force
Remove-Item "C:\Users\*\OneDrive - *\Desktop\*- Copy*.lnk" -Force